
# fusion_app.py
import streamlit as st
import pandas as pd
import io

# Configuración inicial de la app
st.set_page_config(page_title="Fusionador Scopus + WoS", layout="centered")

# ... (el resto del código ya estaba guardado previamente en el editor)
